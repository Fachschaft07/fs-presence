#!/bin/bash
java -jar FSPresenceClient.jar